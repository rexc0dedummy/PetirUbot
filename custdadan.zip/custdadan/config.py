from pyrogram import Client, filters

api_id = '28123355'
api_hash = 'fbe08802d9c36559217b6b86b166c61d'
phone_number = '+6288269795634'

app = Client('a', api_id=api_id, api_hash=api_hash, phone_number=phone_number)

owner = 1935806583
owners = 5889163267
BLACKLIST_CHAT = [-1001805372081, -1001876092598, -1001675452200, -1001868226793, -1001707585565, -1001947304834, -1001927162713, -1001934427872]  # Daftar chat yang ingin dihindari
